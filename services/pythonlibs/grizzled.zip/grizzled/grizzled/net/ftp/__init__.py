"""
FTP-related modules and classes. This module is a conceptual extension to
the standard ``ftplib`` Python module.
"""

__docformat__ = 'restructuredtext en'
