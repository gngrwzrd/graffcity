The [Grizzled Python Utility Library][] is a general-purpose Python library
with a variety of different modules and packages. It's roughly organized
into subpackages that group different kinds of utility functions and
classes.

Grizzled is copyright &copy; 2008-2010 by Brian M. Clapper and is released
under a BSD license.

[Grizzled Python Utility Library]: http://bmc.github.com/grizzled/
