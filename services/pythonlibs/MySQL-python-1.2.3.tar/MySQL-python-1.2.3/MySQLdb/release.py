
__author__ = "Andy Dustman <adustman@users.sourceforge.net>"
version_info = (1,2,3,'final',0)
__version__ = "1.2.3"
